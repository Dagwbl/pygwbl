Dagwbl's personal tool set.

# pygwbl

The pypi module is Dagwbl's personal tool set.  


It offer the function that converting svg to emf.  


Dagwbl's quickTools, You must download Inkscape before using it.
