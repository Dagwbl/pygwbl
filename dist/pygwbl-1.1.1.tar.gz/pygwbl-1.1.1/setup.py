from distutils.core import setup

setup(
    name='pygwbl', 
    version='1.1.1',
    py_modules =['pygwbl'], #这个要跟发布的模块名一致
    author='Dagwbl',
    author_email='Dagwbl@qq.com',
    url='',
    description='这是我的第一个发布'
)